import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserProfileComponent } from './user-profile/user-profile.component';
import { EmployeeUserComponent } from './employee-user/employee-user.component';
import { UserleaveApplyComponent } from './userleave-apply/userleave-apply.component';

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [
    UserProfileComponent,
    EmployeeUserComponent,
    UserleaveApplyComponent
  ],
  exports: [
    UserProfileComponent,
    EmployeeUserComponent,
    UserleaveApplyComponent
  ]
})
export class EmployeeUserModule { }
