import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-user',
  templateUrl: './employee-user.component.html',
  styleUrls: ['./employee-user.component.css']
})
export class EmployeeUserComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
