import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { UserleaveApplyComponent } from './userleave-apply.component';

describe('UserleaveApplyComponent', () => {
  let component: UserleaveApplyComponent;
  let fixture: ComponentFixture<UserleaveApplyComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UserleaveApplyComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UserleaveApplyComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
