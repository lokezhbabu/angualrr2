import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-userleave-apply',
  templateUrl: './userleave-apply.component.html',
  styleUrls: ['./userleave-apply.component.css']
})
export class UserleaveApplyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
