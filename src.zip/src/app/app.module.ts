import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';
import { EmployeeHrModule } from './employee-hr/employee-hr.module';
import { EmployeeUserModule } from './employee-user/employee-user.module';


@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    EmployeeHrModule,
    EmployeeUserModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
