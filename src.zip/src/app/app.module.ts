import { LoginComponent } from './login/login.component';

import { routing } from './app.routing';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { EmployeeHrModule } from './employee-hr/employee-hr.module';
import { EmployeeUserModule } from './employee-user/employee-user.module';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent
  ],
  imports: [
    BrowserModule,
    EmployeeHrModule,
    EmployeeUserModule,
    routing
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
