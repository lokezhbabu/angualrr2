import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-approval',
  templateUrl: './leave-approval.component.html',
  styleUrls: ['./leave-approval.component.css']
})
export class LeaveApprovalComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
