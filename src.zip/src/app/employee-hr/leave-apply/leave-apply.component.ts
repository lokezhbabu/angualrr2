import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-leave-apply',
  templateUrl: './leave-apply.component.html',
  styleUrls: ['./leave-apply.component.css']
})
export class LeaveApplyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
