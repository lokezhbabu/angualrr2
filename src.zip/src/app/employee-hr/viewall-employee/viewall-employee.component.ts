import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewall-employee',
  templateUrl: './viewall-employee.component.html',
  styleUrls: ['./viewall-employee.component.css']
})
export class ViewallEmployeeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
