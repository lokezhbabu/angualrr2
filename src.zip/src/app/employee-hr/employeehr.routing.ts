import { Routes, RouterModule } from '@angular/router';
import { AddUserComponent } from './add-user/add-user.component';
import { EmployeeProfileComponent } from './employee-profile/employee-profile.component';
import { LeaveApplyComponent } from './leave-apply/leave-apply.component';
import { LeaveApprovalComponent } from './leave-approval/leave-approval.component';
import { ViewallEmployeeComponent } from './viewall-employee/viewall-employee.component';
import { EmployeeHrComponent } from './employee-hr/employee-hr.component';
import { BasicComponent } from './employee-profile/basic/basic.component';
import { FamilyComponent } from './employee-profile/family/family.component';
import { EducationComponent } from './employee-profile/education/education.component';

const routes: Routes = [
  { path: '', redirectTo: 'employeeProfile', pathMatch: 'full' },
  { path: 'employeeHR', component: EmployeeHrComponent },
  { path: 'addUser', component: AddUserComponent },
  { path: 'employeeProfile', component: EmployeeProfileComponent,
    children: [
      { path: '', component: EmployeeProfileComponent },
      { path: 'basic', component: BasicComponent },
      { path: 'family', component: FamilyComponent },
      { path: 'education', component: EducationComponent },
  ]


},
  { path: 'leaveApply', component: LeaveApplyComponent },
  { path: 'leaveAproval', component: LeaveApprovalComponent},
  { path: 'viewallEmployee', component: ViewallEmployeeComponent }
];

  export const routing = RouterModule.forRoot(routes);
