import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employee-hr',
  templateUrl: './employee-hr.component.html',
  styleUrls: ['./employee-hr.component.css']
})
export class EmployeeHrComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
