import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EmployeeHrComponent } from './employee-hr.component';

describe('EmployeeHrComponent', () => {
  let component: EmployeeHrComponent;
  let fixture: ComponentFixture<EmployeeHrComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EmployeeHrComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EmployeeHrComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
