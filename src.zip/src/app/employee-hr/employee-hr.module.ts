import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { EmployeeProfileComponent } from './employee-profile/employee-profile.component';
import { ViewallEmployeeComponent } from './viewall-employee/viewall-employee.component';
import { LeaveApplyComponent } from './leave-apply/leave-apply.component';
import { LeaveApprovalComponent } from './leave-approval/leave-approval.component';
import { AddUserComponent } from './add-user/add-user.component';
import { EmployeeHrComponent } from './employee-hr/employee-hr.component';
import { routing } from './employeehr.routing';
import { BasicComponent } from './employee-profile/basic/basic.component';
import { FamilyComponent } from './employee-profile/family/family.component';
import { EducationComponent } from './employee-profile/education/education.component';



@NgModule({
  imports: [
    CommonModule,
    routing
  ],
  declarations: [
    EmployeeProfileComponent,
    ViewallEmployeeComponent,
    LeaveApplyComponent,
    LeaveApprovalComponent,
    AddUserComponent,
    EmployeeHrComponent,
    BasicComponent,
    FamilyComponent,
    EducationComponent
  ],
  exports: [
    EmployeeProfileComponent,
    ViewallEmployeeComponent,
    LeaveApplyComponent,
    LeaveApprovalComponent,
    AddUserComponent,
    EmployeeHrComponent
  ],
})
export class EmployeeHrModule { }
