import { LoginComponent } from './login/login.component';

import { Routes, RouterModule } from '@angular/router';



const routes: Routes = [
  { path: '', redirectTo: 'login', pathMatch: 'full'},
  { path: 'login',component:LoginComponent},
  { path: 'employeeHR', loadChildren: 'app/employee-hr/employee-hr.module#EmployeeHrModule', pathMatch: 'full'},
  { path: 'employeeUser', loadChildren: 'app/employee-user/employee-user.module#EmployeeUserModule', pathMatch: 'full'},
];

export const routing = RouterModule.forRoot(routes);
