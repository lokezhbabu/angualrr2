(function() {
  "use strict";
  angular
    .module("myApp")
    .controller("showEmployeeController", showEmployeeController);
  showEmployeeController.$inject = ["employeeService", "$state"];
  function showEmployeeController(employeeService, $state) {
    var showEmpl = this;
    showEmpl.loadAllEmployees = loadAllEmployees;
    showEmpl.responseData = "";

    loadAllEmployees();

    function loadAllEmployees() {
      return employeeService
        .loadEmployeeData()
        .then(success)
        .catch(failure);
      function success(emplData) {
        showEmpl.responseData = emplData.records;
        console.log(showEmpl.responseData);
      }

      function failure() {
        console.log("error");
        alert("Service loading Error");
      }
    }
  }
})();
