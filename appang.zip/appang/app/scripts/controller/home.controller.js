(function() {

    "use strict";
    angular
    .module('myApp')
    .directive('myExample', myExample);

    function myExample() {
      var directive = {
        restrict: "A",
        //templateUrl: 'app/feature/example.directive.html',
        scope: {
          fileReaderDirective: "=",
        },
        link: function(scope, element) {
          $(element).on('change', function(changeEvent) {
              var files = changeEvent.target.files;
              if (files.length) {
                  var r = new FileReader();
                  r.onload = function(e) {
                      var contents = e.target.result;
                      scope.$apply(function() {
                          scope.fileReaderDirective = contents;
                      });
                  };
                  r.readAsText(files[0]);
              }
          });
      },
        controller: homeController,
        // note: This would be 'ExampleController' (the exported controller name, as string)
        // if referring to a defined controller in its separate file.
        controllerAs: 'home',
        bindToController: true // because the scope is isolated
    };

    return directive;
  }

    angular.module('myApp')
    .controller("homeController", homeController);
    homeController.$inject = ["readFileDataService", "$state"];
      function homeController(readFileDataService, $state) {
        var home = this;
        //home.loadAllEmployees = loadAllEmployees;
        home.fileObject = {};
        home.uploadCSVfile= uploadCSVfile;
        home.fileContent= "";
        home.fileDataObj= "";
        home.fileData= "";
        
        function uploadCSVfile() {
          if (home.fileContent) {
            home.fileDataObj = readFileData.processData(home.fileContent);
            home.fileData = JSON.stringify(home.fileDataObj);
          }
        }
      }
  })();
