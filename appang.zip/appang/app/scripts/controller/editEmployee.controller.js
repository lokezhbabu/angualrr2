(function() {
  "use strict";
  angular
    .module("myApp")
    .controller("editEmployeesController", editEmployeesController);
  editEmployeesController.$inject = ["employeeService", "$state"];
  function editEmployeesController(employeeService, $state) {
    var editEmpl = this;
    editEmpl.loadAllEmployees = loadAllEmployees;
    editEmpl.responseData = [];
    editEmpl.updateEmployee = updateEmployee;
    editEmpl.addNew = addNew;
    editEmpl.filename = "test";



    function loadAllEmployees() {
      return employeeService
        .loadEmployeeData()
        .then(success)
        .catch(failure);
      function success(emplData) {
        editEmpl.responseData = emplData.records;
        console.log(editEmpl.responseData);
      }
      function failure() {
        console.log("error");
        alert("Service loading Error");
      }
    }
    loadAllEmployees();

    function updateEmployee(emplDetails) {
      editEmpl.responseData = emplDetails;
      employeeService.setEmployeeDetails(editEmpl.responseData);
      alert("Details Saved..!!");
    }

    function addNew() {
      editEmpl.responseData.push({
        Name: "",
        City: "",
        Country: ""
      });
    }

    // function addNew() {
    //   editEmpl.responseData.push ({
    //     'Name': "",
    //     'City': "",
    //     'Country': ""
    //   });
    //   console.log(editEmpl.responseData);
    // }
    //   $scope.addNew = function(personalDetail){
    //     $scope.personalDetails.push({
    //         'fname': "",
    //         'lname': "",
    //         'email': "",
    //     });
    // };
  }
})();
