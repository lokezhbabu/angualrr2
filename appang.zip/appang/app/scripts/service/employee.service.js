(function() {
  "use strict";

  angular.module("myApp").factory("employeeService", employeeService);

  employeeService.$inject = ["$http", "$q"];

  function employeeService($http, $q) {
    var service = {
      loadEmployeeData: loadEmployeeData,
      setEmployeeDetails: setEmployeeDetails,
      getEmployeeDetails: getEmployeeDetails,
      employeeDetails: ""
    };
    return service;

    function loadEmployeeData() {
      return $http
        .get("https://www.w3schools.com/angular/customers.php")
        .then(getCompleted) //success block
        .catch(getFailed); //catch block with rejected promise

      function getCompleted(response) {
        return response.data;
      }

      function getFailed(errorReason) {
        var errorMessage = "failed to get data";
        return $q.reject(errorMessage); //returns message to failure block
      }
    }

    function setEmployeeDetails(emplData) {
      this.employeeDetails = emplData;
    }

    function getEmployeeDetails() {
      return this.employeeDetails;
    }
  }
})();
