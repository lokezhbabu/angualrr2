angular
.module('myApp', ["ui.router"])
.config(RunConfig);

RunConfig.$inject = ['$stateProvider', '$urlRouterProvider'];

function RunConfig($stateProvider, $urlRouterProvider) {
    $stateProvider
        .state('root', {
            abstract: true,
            url:''
        })
        .state('root.home', {
            url: '',
            controller: 'homeController',
            templateUrl: 'view/home.html',
        })
        .state('root.showEmployees', {
            url: '/showEmployees',
            controller: 'showEmployeeController',
            templateUrl: 'view/showEmployee.html',
        })
        .state('root.editEmployees',{
            url: '/editEmployees',
            controller: 'editEmployeesController',
            templateUrl: 'view/editEmployee.html'
        })
        .state('root.error',{
            url: '/error',
            template:`<fieldset>
                        <legend>Error</legend>
                        <div> Something went wrong
                            <p>
                                try <a ui-sref="root.home">home</a> page 
                            </p>
                          </div>
                      </fieldset>`
        });


    $urlRouterProvider.otherwise("/error");
}





// var app = angular.module("myApp", []);

// app.controller("myCtrl", function($scope,$http) {
//     $scope.JSON_data = "";
//     $scope.loadmockJSON = function () {
//         $scope.loadtable = true;	
//         $http.get("https://www.w3schools.com/angular/customers.php")
//         .then(function(response) {
//             $scope.responseData = response.data;
//             console.log($scope.responseData.records);
//             $scope.JSON_data = $scope.responseData.records;
//         });
//     };

//     $scope.editJSON = function() {}
// });

// var app = angular.module('myngCsv', []);

// app.controller('ngcsvCtrl', [
//     '$scope',
//     'readFileData',
//     function($scope, readFileData) {
//       $scope.fileDataObj = {};
    
//     $scope.uploadFile = function() {
//       if ($scope.fileContent) {
//         $scope.fileDataObj = readFileData.processData($scope.fileContent);
      
//         $scope.fileData = JSON.stringify($scope.fileDataObj);
//       }
//     }
//  }]);
 
//  app.directive('fileReaderDirective', function() {
//     return {
//         restrict: "A",
//         scope: {
//             fileReaderDirective: "=",
//         },
//         link: function(scope, element) {
//             $(element).on('change', function(changeEvent) {
//                 var files = changeEvent.target.files;
//                 if (files.length) {
//                     var r = new FileReader();
//                     r.onload = function(e) {
//                         var contents = e.target.result;
//                         scope.$apply(function() {
//                             scope.fileReaderDirective = contents;
//                         });
//                     };
//                     r.readAsText(files[0]);
//                 }
//             });
//         }
//     };
// });

// app.factory('readFileData', function() {
//     return {
//         processData: function(csv_data) {
//             var record = csv_data.split(/\r\n|\n/);
//             var headers = record[0].split(',');
//             var lines = [];
//             var json = {};

//             for (var i = 0; i < record.length; i++) {
//                 var data = record[i].split(',');
//                 if (data.length == headers.length) {
//                     var tarr = [];
//                     for (var j = 0; j < headers.length; j++) {
//                         tarr.push(data[j]);
//                     }
//                     lines.push(tarr);
//                 }
//             }
            
//             for (var k = 0; k < lines.length; ++k){
//               json[k] = lines[k];
//             }
//             return json;
//         }
//     };
// });